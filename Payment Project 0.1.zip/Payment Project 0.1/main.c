#include "Payment Project 0.1/Application/app.h"


void main() {
	appStart();
}